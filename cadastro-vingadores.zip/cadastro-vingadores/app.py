from model.interface import Interface

def main():
    Interface()

if __name__ == '__main__':
    main()
